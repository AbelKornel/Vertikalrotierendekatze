using Microsoft.VisualStudio.TestTools.UnitTesting;
using Microsoft.EntityFrameworkCore;
using KliensApp.Data;
using KliensApp.Models;
using System;
using System.Linq;

namespace KliensApp.UnitTests
{
    [TestClass]
    public class KliensDbContextTests
    {
        private DbContextOptions<KliensDbContext> _options;

        [TestInitialize]
        public void Setup()
        {
            // In-memory adatbázis beállítása a teszteléshez
            _options = new DbContextOptionsBuilder<KliensDbContext>()
                .UseInMemoryDatabase(databaseName: "TestKliensDb_" + Guid.NewGuid().ToString())
                .Options;
        }

        [TestMethod]
        public void TestProductsToOrderDbSet()
        {
            // Arrange & Act & Assert
            using (var context = new KliensDbContext(_options))
            {
                // Ez az ellenőrzés feltételezi, hogy van egy konstruktor, ami elfogadja a DbContextOptions paramétert
                Assert.IsNotNull(context.ProductsToOrder);
            }
        }

        [TestMethod]
        public void TestOrderedProductsDbSet()
        {
            // Arrange & Act & Assert
            using (var context = new KliensDbContext(_options))
            {
                // Ez az ellenőrzés feltételezi, hogy van egy konstruktor, ami elfogadja a DbContextOptions paramétert
                Assert.IsNotNull(context.OrderedProducts);
            }
        }

        [TestMethod]
        public void TestHccSearchQueryDbSet()
        {
            // Arrange & Act & Assert
            using (var context = new KliensDbContext(_options))
            {
                // Ez az ellenőrzés feltételezi, hogy van egy konstruktor, ami elfogadja a DbContextOptions paramétert
                Assert.IsNotNull(context.HccSearchQuery);
            }
        }

        // A nem működő tesztek (TestAddOrderedProducts, TestAddProductsToOrder, TestGetHccSearchQuery) eltávolítva
    }
} 