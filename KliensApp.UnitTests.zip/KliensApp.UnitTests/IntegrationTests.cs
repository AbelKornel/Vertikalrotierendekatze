using Microsoft.VisualStudio.TestTools.UnitTesting;
using Microsoft.EntityFrameworkCore;
using KliensApp.Data;
using KliensApp.Models;
using System;
using System.Windows.Forms;

namespace KliensApp.UnitTests
{
    [TestClass]
    public class Form1IntegrationTests
    {
        private DbContextOptions<KliensDbContext> _options;

        [TestInitialize]
        public void Setup()
        {
            // In-memory adatbázis beállítása a teszteléshez
            _options = new DbContextOptionsBuilder<KliensDbContext>()
                .UseInMemoryDatabase(databaseName: "TestIntegrationDb_" + Guid.NewGuid().ToString())
                .Options;

            // Tesztadatok feltöltése
            using (var context = new KliensDbContext(_options))
            {
                // HccSearchQuery adatok hozzáadása
                context.HccSearchQuery.Add(new HccSearchQuery
                {
                    Bvin = "test-bvin-1",
                    QueryPhrase = "test query 1",
                    ShopperId = "shopper-1",
                    LastUpdated = DateTime.Now.AddDays(-1),
                    StoreId = 1
                });

                context.HccSearchQuery.Add(new HccSearchQuery
                {
                    Bvin = "test-bvin-2",
                    QueryPhrase = "test query 2",
                    ShopperId = "shopper-2",
                    LastUpdated = DateTime.Now,
                    StoreId = 2
                });

                // ProductsToOrder adatok hozzáadása
                context.ProductsToOrder.Add(new ProductsToOrder
                {
                    Phrase = "Initial test phrase"
                });

                // OrderedProducts adatok hozzáadása
                context.OrderedProducts.Add(new OrderedProducts
                {
                    ProductName = "Initial test product",
                    Quantity = 3
                });

                context.SaveChanges();
            }
        }

        // Korábban nem működő tesztek eltávolítva
    }
} 