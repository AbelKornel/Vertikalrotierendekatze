using Microsoft.VisualStudio.TestTools.UnitTesting;
using KliensApp.Models;
using System;

namespace KliensApp.UnitTests
{
    [TestClass]
    public class ProductsToOrderTests
    {
        [TestMethod]
        public void TestProductsToOrderProperties()
        {
            // Arrange
            var product = new ProductsToOrder
            {
                Id = 1,
                Phrase = "Teszt termék"
            };

            // Assert
            Assert.AreEqual(1, product.Id);
            Assert.AreEqual("Teszt termék", product.Phrase);
        }

        [TestMethod]
        public void TestProductsToOrderIdDefaultValue()
        {
            // Arrange
            var product = new ProductsToOrder();

            // Assert
            Assert.AreEqual(0, product.Id);
        }

        [TestMethod]
        public void TestProductsToOrderPhraseNullable()
        {
            // Arrange
            var product = new ProductsToOrder();

            // Assert
            Assert.IsNull(product.Phrase);
        }
    }

    [TestClass]
    public class OrderedProductsTests
    {
        [TestMethod]
        public void TestOrderedProductsProperties()
        {
            // Arrange
            var orderedProduct = new OrderedProducts
            {
                OrderId = 1,
                ProductName = "Teszt termék",
                Quantity = 5
            };

            // Assert
            Assert.AreEqual(1, orderedProduct.OrderId);
            Assert.AreEqual("Teszt termék", orderedProduct.ProductName);
            Assert.AreEqual(5, orderedProduct.Quantity);
        }

        [TestMethod]
        public void TestOrderedProductsIdDefaultValue()
        {
            // Arrange
            var orderedProduct = new OrderedProducts();

            // Assert
            Assert.AreEqual(0, orderedProduct.OrderId);
        }

        [TestMethod]
        public void TestOrderedProductsQuantityNullable()
        {
            // Arrange
            var orderedProduct = new OrderedProducts();

            // Assert
            Assert.IsNull(orderedProduct.Quantity);
        }
    }
} 